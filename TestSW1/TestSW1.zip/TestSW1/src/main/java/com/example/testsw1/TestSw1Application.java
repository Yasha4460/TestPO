package com.example.testsw1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSw1Application {

    public static void main(String[] args) {
        SpringApplication.run(TestSw1Application.class, args);
    }

}
